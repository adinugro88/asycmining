<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h5><b>Daftar Mesin</b></h5></div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">QTY</th>
                                <th scope="col">nama Mesin</th>
                                <th scope="col">Watt</th>
                                <th scope="col">Coin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no =0; ?>
                            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $no ++ ?>
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($post -> Qty); ?></td>
                                <td><?php echo e($post -> namamesin); ?></td>
                                <td><?php echo e($post -> watt); ?></td>
                                <td><?php echo e($post -> coin); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>

            <h4 class="mt-4"><b>Pilih Coin</b></h4>
            <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a type="button" class="btn btn-info <?php echo e(request()->is('$db->coin*')  ? 'active' : ''); ?>" href="/coin/<?php echo e($db->coin); ?>"><?php echo e($db->coin); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            <div class="card mt-5" id="laporanperday">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-12  mb-5">
                        <select name="filter" id="" class="form-select"  onchange="location =this.value;">
                            <?php $__currentLoopData = $jmltgl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="/coindate/<?php echo e($datacoin); ?>/<?php echo e($db->tgl); ?>" <?php echo e($db->tgl == $tgl ? 'selected' : ''); ?>>
                                        <?php echo e(\Carbon\Carbon::parse($db->tgl)->format('d M Y')); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                        <div class="col-md-4 col-12">
                            <h5><b>
                                Tanggal :
                                <?php echo e(\Carbon\Carbon::parse($tgl)->format('d M Y')); ?>

                            </b></h5>
                        </div>
                        <div class="col-md-4 col-12">
                           
                            <h5><b>
                                Total Coin  <?php echo e($datacoin); ?>/Day :
                                <?php echo e(number_format( $totalcoin,8)); ?>

                            </b></h5>
                            
                        </div>
                        <div class="col-md-4 col-12 text-right">
                 
                            <h5><b>
                                <?php echo e($datacoin); ?> TOTAL :
                                <?php echo e("Rp " . number_format( $total, 0, ",", ".")); ?>

                            </b></h5>
                            
                        </div>
                    </div>
                </div>

                <div class="card-body">



                    <table class="table table table-responsive w-100 d-block d-md-table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Mesin</th>
                                <th scope="col">Watt</th>
                                <th scope="col">income</th>
                                <!--<th scope="col">Mesin Aktif</th>-->
                                <th scope="col">Listrik</th>
                                <th scope="col">Income - Listrik </th>
                                <th scope="col">Investor</th>
                                <th scope="col">Rate</th>
                                <th scope="col">Convert in IDR</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0 ?>
                            <?php $__currentLoopData = $miner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $no++  ?>
                            
                            <tr>
                                <th scope="row"><?php echo e($no); ?></th>
                                <td><?php echo e($db->mesin); ?></td>
                                <td><?php echo e($db->watt); ?></td>
                                <td><?php echo e(number_format($db->nilaisbr,9)); ?></td>
                                <!--<td><?php echo e($db->active_mesin); ?> Jam</td>-->
                                <td><?php echo e(number_format($db->listrik,9)); ?></td>
                                <td><?php echo e(number_format($db->hasillistrikkurang,9)); ?></td>
                                <td><?php echo e(number_format($db->investor,9)); ?></td>
                                <td><?php echo e("Rp " . number_format( $db->rate, 0, ",", ".")); ?></td>
                                <td><?php echo e("Rp " . number_format( $db->INVERT_IDR, 0, ",", ".")); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="row">
                        <div class="col-md-12 text-center">
                            <?php echo e($miner->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>

                

            </div>

            <div class="row">

                <div class="col-md-6">
                    <div class="card mt-5">
                        <div class="card-header"><h5><b> Total Wallet</b></h5></div>
                        <div class="card-body">
                            <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Coin</th>
                                        <th scope="col">Total Coin </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no =0; ?>
                                    <?php $__currentLoopData = $totalweek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $no ++ ?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($db -> coin); ?></td>
                                        <td><?php echo e(number_format($db -> totalwallet,9)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
        
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card mt-5">
                        <div class="card-header"><h5><b> Total Listrik</b></h5></div>
                        <div class="card-body">
                            <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Coin</th>
                                        <th scope="col">Listrik</th>
                                        <th scope="col">Listrik In IDR </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no =0; ?>
                                    <?php $__currentLoopData = $totalweek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $no ++ ?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($db -> coin); ?></td>
                                        <td><?php echo e($db -> totallistrik); ?></td>
                                       
                                        <td><?php echo e("Rp " . number_format($db -> ratelistrik, 0, ",", ".")); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
        
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-12">
                    <div class="card mt-5">
                        <div class="card-header"><h5><b> Total Pendapatan</b></h5></div>
                        <div class="card-body">
                            <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col" rowspan="1">No</th>
                                        <th scope="col" rowspan="1">Coin</th>
                                        <th scope="col" rowspan="1">wallet</th>
                                        <th scope="col" rowspan="1">Listrik</th>
                                        <th scope="col" rowspan="1">Wallet - Listrik</th>
                                        <th scope="col" colspan="2" style="text-align: center">Bagi Hasil</th>
                                    </tr>
                                    <tr style="border: 0">
                                        <th ></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th colspan="">Investor</th>
                                        <th colspan="">Manajemen</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no =0; ?>
                                    <?php $__currentLoopData = $totalweek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $no ++ ?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($db -> coin); ?></td>
                                        <td><?php echo e(number_format($db -> totalwallet,8)); ?></td>
                                        <td><?php echo e($db -> totallistrik); ?></td>
                                        <td><?php echo e(number_format($db -> hslkrglistrik,8)); ?></td>
                                        <td><?php echo e(number_format($db -> total,9)); ?></td>
                                        <td><?php echo e(number_format($db -> totalmanage,9)); ?></td>
        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="5" class="text-right"><b>Estimasi Pendapatan</b></td>
        
                                        <td><b> <?php echo e("Rp " . number_format($totalIncome, 0, ",", ".")); ?>

                                        </b></td>
                                        <td><b> <?php echo e("Rp " . number_format($totalIncomeMNJ, 0, ",", ".")); ?>

                                        </b></td>
                                    </tr>
        
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 mt-5">
                    <div class="card">            
                        <div class="card-header mt-0">
                            <h5>List Payment</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-fit">
                                    <thead class="">
                                        <tr style=" white-space: nowrap;">
                                            <th scope="col" style="width: auto">No</th>
                                            
                                            <th scope="col" style="width: auto">Tanggal Transaksi </th>
                                            <th scope="col">Coin</th>
                                            <th scope="col">Wallet</th>
                                            <th scope="col">Network Fee</th>
                                            <th scope="col">Wallet Company</th>
                                            <th scope="col">listrik</th>
                                            <th scope="col">investor</th>
                                            <th scope="col">Management</th>
                                            <th scope="col">Rate Coin To USDT</th>
                                            <th scope="col">Fee Coin To USDT</th>
                                            <th scope="col">Total USDT</th>
                                            <th scope="col">Rate USDT to Bidr</th>
                                            <th scope="col">Fee Bidr</th>
                                            <th scope="col">Total Bidr</th>
                                            <th scope="col">Fee Coin To Idr</th>
                                            <th scope="col">fee Coin To BTC</th>
                                            <th scope="col">Total Coin To BTC</th>
                                            <th scope="col">Total In IDR</th>
                                            <th scope="col">Tanggal Transaksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no =0; ?>
                                        <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $no ++ ?>
                                        <tr style=" white-space: nowrap;">
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($post ->catatan); ?></td>
                                            <td><?php echo e($post ->coin); ?></td>
                                            <td><?php echo e(number_format($post ->wallet,8)); ?></td>
                                            <td><?php echo e(number_format($post ->networkfee,6)); ?></td>
                                            <td><?php echo e(number_format( $post ->walletcompany ,6)); ?> </td>
                                            <td><?php echo e(number_format($post ->listrik ,6)); ?> </td>
                                            <td><?php echo e(number_format($post ->investor ,6)); ?></td>
                                            <td><?php echo e(number_format($post ->management ,6)); ?></td>
                                            <td><?php echo e($post ->ratecointousd); ?></td>
                                            <?php if($post ->feecoin != 0): ?>
                                            <td><?php echo e(number_format($post ->feecointousd ,6)); ?></td>
                                            <?php else: ?>
                                            <td><?php echo e($post ->feecointousd); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($post ->totalusd); ?></td>
                                            <td><?php echo e($post ->rateusdtobidr); ?></td>
                                            <td><?php echo e($post ->feebidr); ?></td>
                                            <td><?php echo e($post ->totalbidr); ?></td>
                                            
                                            <td><?php echo e($post ->feecointoidr); ?></td>
                                            <?php if($post ->feecoin != 0): ?>
                                            <td><?php echo e(number_format($post ->feecoin ,6)); ?></td>
                                            <?php else: ?>
                                            <td><?php echo e($post ->feecoin); ?></td>
                                            <?php endif; ?>
                                            
                
                                            <td><?php echo e($post ->totalcoin); ?> </td>
                                            <td> <?php echo e("Rp " . number_format($post ->total, 0, ",", ".")); ?></td>
                                            <td> <?php echo e(\Carbon\Carbon::parse( $post ->tanggal )->format('d M Y')); ?></td>
                                            
                                    
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                </div>

              
                
            </div>

           
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DIGITAL AGENCY KHARISMA\PROGRAM MINING\SEMENTARA_MINING\blog\resources\views/coincustom.blade.php ENDPATH**/ ?>