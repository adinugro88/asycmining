<div class="container">
    <div class="col-md-3 mb-5">

        <h4>Investor<b>&nbsp; <?php echo e($investor->name); ?></b></h4>
        <button type="button" class="btn btn-primary" wire:click="$set('show', true)">
            Tambah Data
        </button>
    </div>

    <?php echo $__env->make('livewire.incomecreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-6  mt-5">
        <div class="row">
            <div class="col-md-2">
                <b class="mt-5">Pilih Coin</b>
            </div>
            <div class="col-md-6">
                <div class="form-group">

                    <select class="custom-select" wire:model="ubah">
                        <?php $__currentLoopData = $listcoin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($db->coin); ?>"><?php echo e($db->coin); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>



    <?php echo $__env->make('livewire.incomedel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-12">
        <div class="card">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-info mb-0" id="alertoi" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>

            <div class="card-header mt-0">
                <h5>List Mesin</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Coin</th>
                            <th scope="col">Mesin</th>
                            <th scope="col">Total Coin Per Hari</th>
                            <th scope="col">action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no =0; ?>
                        <?php $__currentLoopData = $datahasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no ++ ?>
                        <tr>
                            <td><?php echo e($key+ $datahasil->firstItem()); ?></td>
                            <td><?php echo e($post -> tgl); ?></td>
                            <td><?php echo e($post -> coin); ?></td>
                            <td><?php echo e($post -> mesin); ?></td>
                            <td><?php echo e($post -> nilai); ?></td>

                            <td>

                                <button wire:click="selectedItem(<?php echo e($post->id); ?>,'delete')" type="button"
                                    class="btn btn-danger">Hapus</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>

                

                <div>
                    <?php if($datahasil->hasPages()): ?>
                        <nav role="navigation" aria-label="Pagination Navigation" class="flex justify-between">
                            <span>
                                
                                <?php if($datahasil->onFirstPage()): ?>
                                    <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 cursor-default leading-5 rounded-md">
                                        <?php echo __('pagination.previous'); ?>

                                    </span>
                                <?php else: ?>
                                    <button wire:click="previousPage" wire:loading.attr="disabled" rel="prev" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 leading-5 rounded-md hover:text-gray-500 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150">
                                        <?php echo __('pagination.previous'); ?>

                                    </button>
                                <?php endif; ?>
                            </span>
                
                            <span>
                                
                                <?php if($datahasil->hasMorePages()): ?>
                                    <button wire:click="nextPage" wire:loading.attr="disabled" rel="next" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 leading-5 rounded-md hover:text-gray-500 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150">
                                        <?php echo __('pagination.next'); ?>

                                    </button>
                                <?php else: ?>
                                    <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 cursor-default leading-5 rounded-md">
                                        <?php echo __('pagination.next'); ?>

                                    </span>
                                <?php endif; ?>
                            </span>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\DIGITAL AGENCY KHARISMA\PROGRAM MINING\SEMENTARA_MINING\blog\resources\views/livewire/income-crud.blade.php ENDPATH**/ ?>