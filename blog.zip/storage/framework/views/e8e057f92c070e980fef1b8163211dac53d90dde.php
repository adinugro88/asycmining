
   
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mesin-crud',['id'=>$id])->html();
} elseif ($_instance->childHasBeenRendered('aZKfIVX')) {
    $componentId = $_instance->getRenderedChildComponentId('aZKfIVX');
    $componentTag = $_instance->getRenderedChildComponentTagName('aZKfIVX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aZKfIVX');
} else {
    $response = \Livewire\Livewire::mount('mesin-crud',['id'=>$id]);
    $html = $response->html();
    $_instance->logRenderedChild('aZKfIVX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DIGITAL AGENCY KHARISMA\PROGRAM MINING\SEMENTARA_MINING\blog\resources\views/admin/mesincrud.blade.php ENDPATH**/ ?>