
   
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('income-crud',['id'=>$id])->html();
} elseif ($_instance->childHasBeenRendered('w6mo6GJ')) {
    $componentId = $_instance->getRenderedChildComponentId('w6mo6GJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('w6mo6GJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('w6mo6GJ');
} else {
    $response = \Livewire\Livewire::mount('income-crud',['id'=>$id]);
    $html = $response->html();
    $_instance->logRenderedChild('w6mo6GJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DIGITAL AGENCY KHARISMA\PROGRAM MINING\SEMENTARA_MINING\blog\resources\views/admin/incomecrud.blade.php ENDPATH**/ ?>