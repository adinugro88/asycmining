
   
<?php $__env->startSection('content'); ?>
<div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('investor')->html();
} elseif ($_instance->childHasBeenRendered('8Wc1gSS')) {
    $componentId = $_instance->getRenderedChildComponentId('8Wc1gSS');
    $componentTag = $_instance->getRenderedChildComponentTagName('8Wc1gSS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8Wc1gSS');
} else {
    $response = \Livewire\Livewire::mount('investor');
    $html = $response->html();
    $_instance->logRenderedChild('8Wc1gSS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DIGITAL AGENCY KHARISMA\PROGRAM MINING\SEMENTARA_MINING\blog\resources\views/admin/investor.blade.php ENDPATH**/ ?>