<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Daftar Mesin</div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">QTY</th>
                                <th scope="col">nama Mesin</th>
                                <th scope="col">Watt</th>
                                <th scope="col">Coin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no =0; ?>
                            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $no ++ ?>
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($post -> Qty); ?></td>
                                <td><?php echo e($post -> namamesin); ?></td>
                                <td><?php echo e($post -> watt); ?></td>
                                <td><?php echo e($post -> coin); ?></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card mt-5">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <?php $__currentLoopData = $jmltgl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($db->tgl == $tgl): ?>
                            <a href="/home/<?php echo e($db->tgl); ?>">
                                <b>
                                    <?php echo e(\Carbon\Carbon::parse($db->tgl)->format('d M ')); ?>

                                </b>
                            </a>
                            <?php else: ?>
                            <a href="/home/<?php echo e($db->tgl); ?>">
                            <?php echo e(\Carbon\Carbon::parse($db->tgl)->format('d M ')); ?>

                            </a>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-md-6">
                            <b>
                                Tanggal :
                                <?php echo e(\Carbon\Carbon::parse($tgl)->format('d M Y')); ?>

                            </b>
                        </div>
                        <div class="col-md-6 text-right">

                            <b> 
                                BCH Total :
                                 
                                
                                <?php echo e("Rp " . number_format( $total, 0, ",", ".")); ?></b>
                        </div>
                    </div>
                </div>

                <div class="card-body">



                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Mesin</th>
                                <th scope="col">Watt</th>
                                <th scope="col">income</th>
                                <!--<th scope="col">Mesin Aktif</th>-->
                                <th scope="col">Listrik</th>
                                <th scope="col">Listrik - Income</th>
                                <th scope="col">Investor</th>
                                <th scope="col">Rate</th>
                                <th scope="col">Convert in IDR</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0 ?>
                            <?php $__currentLoopData = $miner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $no++  ?>
                            
                            <tr>
                                <th scope="row"><?php echo e($no); ?></th>
                                <td><?php echo e($db->mesin); ?></td>
                                <td><?php echo e($db->watt); ?></td>
                                <td><?php echo e(number_format($db->nilaisbr,9)); ?></td>
                                <!--<td><?php echo e($db->active_mesin); ?> Jam</td>-->
                                <td><?php echo e(number_format($db->listrik,9)); ?></td>
                                <td><?php echo e(number_format($db->hasillistrikkurang,9)); ?></td>
                                <td><?php echo e(number_format($db->investor,9)); ?></td>
                                <td><?php echo e("Rp " . number_format( $db->rate, 0, ",", ".")); ?></td>
                                <td><?php echo e("Rp " . number_format( $db->INVERT_IDR, 0, ",", ".")); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="row">
                        <div class="col-md-12 text-center">
                            <?php echo e($miner->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>

                <div class="card-footer">
                    <?php $__currentLoopData = $totalweek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <b>Total in Week : <?php echo e("Rp " . number_format( $db->sum, 0, ",", ".")); ?> </b>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1256400/blog/resources/views/hometgl.blade.php ENDPATH**/ ?>