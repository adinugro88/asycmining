
   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12">
        <div class="card">

            <?php if(session()->has('message')): ?>
            <div class="alert alert-info mb-0" id="alertoi" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            
            <div class="card-header mt-0">
                <h5><b>List Investor</b></h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no =0; ?>
                        <?php $__currentLoopData = $listinvestor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no ++ ?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($post -> name); ?></td>
                            <td>
                                <a href="/admin/income/<?php echo e($post -> id); ?>" class="btn btn-primary" >Input Data</a>
                               
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DIGITAL AGENCY KHARISMA\PROGRAM MINING\SEMENTARA_MINING\blog\resources\views/admin/income.blade.php ENDPATH**/ ?>