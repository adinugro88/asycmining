@extends('layouts.app')
   
@section('content')
<div class="container">
        @livewire('investor')
</div>
@endsection