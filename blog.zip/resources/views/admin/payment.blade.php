@extends('layouts.app')
   
@section('content')
@livewire('payment-crud')
@endsection
