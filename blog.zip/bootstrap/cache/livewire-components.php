<?php return array (
  'income-crud' => 'App\\Http\\Livewire\\IncomeCrud',
  'investor' => 'App\\Http\\Livewire\\Investor',
  'mesin-crud' => 'App\\Http\\Livewire\\MesinCrud',
  'payment-crud' => 'App\\Http\\Livewire\\PaymentCrud',
);